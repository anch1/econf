insert into dict(name, dict_name) values ('Архитектура','рнаук');
insert into dict(name, dict_name) values ('Биологические науки','рнаук');
insert into dict(name, dict_name) values ('Ветеринарные науки','рнаук');
insert into dict(name, dict_name) values ('Военные науки','рнаук');
insert into dict(name, dict_name) values ('Географические науки','рнаук');